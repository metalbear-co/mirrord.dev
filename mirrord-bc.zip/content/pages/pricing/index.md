---
title: Pricing
description: mirrord for Teams plans and pricing
slug: pricing
questions:
  - title: "How are seats calculated?"
    content: >
      Seats are calculated by monthly activity. Any user that used mirrord in a calendar month is counted towards your seat count.mirrord identifies users with a unique file it creates on the machine it runs on. If this does not represent distinct users in your organization, or if you use mirrord on cloud workers (e.g. for CI, or cloud development environments), please <a href="/contact/">contact us</a>
  - title: "How are seats calculated?"
    content: >
      Seats are calculated by monthly activity. Any user that used mirrord in a calendar month is counted towards your seat count.mirrord identifies users with a unique file it creates on the machine it runs on.
  - title: "How are seats calculated?"
    content: >
      Seats are calculated by monthly activity. Any user that used mirrord in a calendar month is counted towards your seat count.mirrord identifies users with a unique file it creates on the machine it runs on. If this does not represent distinct users in your organization, or if you use mirrord on cloud workers (e.g. for CI, or cloud development environments), please <a href="/contact/">contact us</a>
  - title: "How are seats calculated?"
    content: >
      Seats are calculated by monthly activity. Any user that used mirrord in a calendar month is counted towards your seat count.mirrord identifies users with a unique file it creates on the machine it runs on. If this does not represent distinct users in your organization, or if you use mirrord on cloud workers (e.g. for CI, or cloud development environments), please <a href="/contact/">contact us</a>
layout: pricing
---
