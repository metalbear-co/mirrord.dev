---
title : "mirrord"
description: "mirrord lets you reflect your changes in local code to a k8s cluster without building or deploying"
date: 2020-10-06T08:47:36+00:00
lastmod: 2020-10-06T08:47:36+00:00
draft: false
images: []
---
