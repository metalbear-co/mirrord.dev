---
title : "mirrord"
description: "mirrord lets you run local processes in the real-time context of your k8s environment, and test continuously in the cloud going through CI and deployment."
lead: "mirrord lets you run local processes in the real-time context of your k8s environment, and test continuously in the cloud going through CI and deployment."
date: 2020-10-06T08:47:36+00:00
lastmod: 2020-10-06T08:47:36+00:00
draft: false
images: []
---