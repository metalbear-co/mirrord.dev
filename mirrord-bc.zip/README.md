## mirrord.dev 🪞

mirrord docs site hosted by Cloudflare Pages and built using [Doks](https://getdoks.org/).

This repository is [MIT Licensed](LICENSE).


### Running
`yarn dev`